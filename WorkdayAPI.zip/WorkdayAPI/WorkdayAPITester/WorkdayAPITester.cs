﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using WorkdayAPI;
using WorkdayAPI.HumanResources;
using WorkdayAPITester.Properties;

namespace WorkdayAPITester
{
    public partial class WorkdayAPITester : Form
    {
        private HumanResourcesAPI oWDWorker;
      string sUser = System.Configuration.ConfigurationSettings.AppSettings["WorkdayAccountUsername"];
      string sPass = System.Configuration.ConfigurationSettings.AppSettings["WorkdayAccountPassword"];
    public WorkdayAPITester()
        {
            InitializeComponent();

            string sEndpoint =System.Configuration.ConfigurationSettings.AppSettings["WorkdayWebserviceEndpointProduction"];

            oWDWorker = new HumanResourcesAPI(sEndpoint, sUser, sPass, MyHandleErr);

            dtDateFrom.Text = DateTime.Now.AddDays(-120).ToString();
            dtDateThrough.Text = DateTime.Now.ToString();

        }

        private void btnGetWorker_Click(object sender, EventArgs e)
        {
            try
            {
                string sEmployeeID = txtEmployeeID.Text.ToString(), sDataType = cboGetDataType.Text;
                DateTime dFrom = Convert.ToDateTime(dtDateFrom.Text);
                DateTime dThrough = Convert.ToDateTime(dtDateThrough.Text);

                // TODO show output from objects below in results window 
                switch (sDataType)
                {
                    case "Worker":
                            // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Get_Workers.html
                           Worker_DataType oGetWorkerData = oWDWorker.GetWorkerData(sEmployeeID);


                            break;

                    case "Employee":
                        // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Get_Employee.html
                        EmployeeType oEmployee = oWDWorker.GetEmployee(sEmployeeID, dThrough);
                        break;

                    case "Profile":
                        // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Get_Worker_Profile.html
                        Worker_ProfileType oProfile = oWDWorker.GetWorkerProfile(sEmployeeID, dThrough);
                        break;

                    case "Event History":
                        // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Get_Worker_Event_History.html
                        Worker_Event_HistoryType oHistory = oWDWorker.GetWorkerEventHistory(txtEmployeeID.Text, dFrom, dThrough, HumanResourcesAPI.DateSelectionType.DataEntry);
                        break;

                    case "Account":
                        // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Get_Workday_Account.html
                        Get_Workday_Account_ResponseType oWorkdayAccount = oWDWorker.GetWorkdayAccount(sEmployeeID, 0, 0, HumanResourcesAPI.DateSelectionType.DataEntry, dThrough);
 
                        break;

                    case "Related Persons":
                        // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Get_Employee_Related_Persons.html
                        Employee_Related_PersonsType oEmployeeRelatedPersons = oWDWorker.GetEmployeeRelatedPersons(sEmployeeID);
                        break;

                    default:
                        if (sDataType == "")
                        {
                            txtResults.Text = "Please select a Data Type to retrieve data for.";
                        }
                        else
                        {
                            txtResults.Text = sDataType + " currently not supported.";
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                MyHandleErr(ex);
            }

        }



        private void btnGetWorkers_Click(object sender, EventArgs e)
        {

            try
            {
                Get_Workers_ResponseType oGetWorkers = oWDWorker.GetWorkers(HumanResourcesAPI.DateSelectionType.DataEntry,DateTime.Now, 10, 1);
            }
            catch (Exception ex)
            {
                MyHandleErr(ex);
            }
        }


        private void btnUpdateData_Click(object sender, EventArgs e)
        {
            try
            {
                if (CheckEmployeeID())
                {
                    string sEmployeeID = txtEmployeeID.Text.ToString(), sDataType = cboUpdateDataType.Text, sUpdateDataTo=txtUpdateDataTo.Text;

                    if (sUpdateDataTo == "")
                    {
                        txtResults.Text = "Please enter a value to update the data to.";
                        return;
                    }

                    switch (sDataType)
                    {
                        case "Phone":
                            // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Maintain_Contact_Information.html
                            oWDWorker.UpdateEmployeePhone(sEmployeeID,"1","", sUpdateDataTo, "", HumanResourcesAPI.ContactType.WORK, HumanResourcesAPI.PhoneDeviceType.Landline, chkUpdatePrimary.Checked, chkMakePublic.Checked, chkCreateNew.Checked,false);
                            break;

                        case "Email":
                            // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Maintain_Contact_Information.html
                            oWDWorker.UpdateEmployeeEmail(sEmployeeID, sUpdateDataTo, HumanResourcesAPI.ContactType.HOME, chkUpdatePrimary.Checked, chkMakePublic.Checked, chkCreateNew.Checked, false);
                            break;

                        case "Username":
                            // See object heirarchy at https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Update_Workday_Account.html
                            oWDWorker.UpdateWorkdayAccountUserName(sEmployeeID, sUpdateDataTo);
                            break;

                        default:
                            if (sDataType == "")
                            {
                                txtResults.Text = "Please select an Update Data Type.";
                            }
                            else
                            {
                                txtResults.Text =sDataType + " currently not supported";
                            }
                            break;
                    }
                }
            } catch (Exception ex)
            {
                MyHandleErr(ex);
            }
        }


        private Boolean CheckEmployeeID()
        {
            
            if (txtEmployeeID.Text.Trim() == "")
            {
                txtResults.Text = "Please supply a valid Employee ID.";
                return false;
            }
            else
            {
                return true;
            }

        }


        private void MyHandleErr(Exception ex)
        {

            string sMessage = ex.Message;
            string sSource = ex.Source;
            string sTargetSite = ex.TargetSite.ToString();
            string sStackTrace = ex.StackTrace;
            if ((ex.InnerException != null))
            {
                if (string.IsNullOrEmpty(ex.InnerException.Message))
                    sMessage += "\n\nInner Exception Message - " + ex.InnerException.Message;
                if (string.IsNullOrEmpty(ex.InnerException.Source))
                    sSource += "\n\nInner Exception Source - " + ex.InnerException.Source;
                if (string.IsNullOrEmpty(ex.InnerException.TargetSite.ToString()))
                    sTargetSite += "\n\nInner Exception Target Site - " + ex.InnerException.TargetSite.ToString();
                if (string.IsNullOrEmpty(ex.InnerException.StackTrace))
                    sStackTrace = "\n\nInner Exception Stack Trace - " + ex.InnerException.StackTrace;
            }

            txtResults.Text = "Error Information - " + DateTime.Now + "\n\nMESSAGE - " + sMessage + "\n\nSOURCE - " + sSource + "\n\nTARGET SITE - " + sTargetSite + "\n\nSTACK TRACE - " + sStackTrace ;

//            Console.WriteLine(sErrorDetails);
        }

    private void btnRunDev_Click(object sender, EventArgs e)
    {
      try
      {
        WorkdayAPI.ReportsAPI oReport = new WorkdayAPI.ReportsAPI(sUser, sPass, MyHandleErr);
        //string sEndpoint = System.Configuration.ConfigurationSettings.AppSettings["WorkdayLocationDirectoryReportWebserviceEndpointProduction"];
        //oReport.RunLocationDirectory("28.1", sEndpoint);


        //        Worker_Event_HistoryType oWorkHist = oWDWorker.GetWorkerEventHistory("801439", DateTime.Now.AddYears(-1), DateTime.Now, HumanResourcesAPI.DateSelectionType.Effective);

        List<Location_ResponseType> oLocResp = oWDWorker.GetAllLocations();
//        List<Job_Profile_Get_DataType> oJobProfiles = oWDWorker.GetAllJobProfiles();

      }
      catch (Exception ex)
      {
        MyHandleErr(ex);
      }

    }
  }
}

