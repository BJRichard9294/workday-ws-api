﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WorkdayAPI.TimeTracking;

namespace WorkdayAPI
{
    class TimeTrackingAPI
    {
        private const string pcsVersion = "v26.2";
        private string psEndpointAddress, psUsername, psPassword;
        private Workday_Common_HeaderType oCommonHeader = null;

        /// <summary>
        /// Class constructor.  Must supply the Endpoint Address and login Username/Password
        /// </summary>
        /// <param name="sEndpointAddress"></param>
        /// <param name="sUsername"></param>
        /// <param name="sPassword"></param>
        public TimeTrackingAPI(string sEndpointAddress, string sUsername, string sPassword)
        {
            psEndpointAddress = sEndpointAddress;
            psUsername = sUsername;
            psPassword = sPassword;
            oCommonHeader = new Workday_Common_HeaderType();
            oCommonHeader.Include_Reference_Descriptors_In_Response = false;
            oCommonHeader.Include_Reference_Descriptors_In_ResponseSpecified = true;
        }

        private Time_TrackingPortClient GetPortClient()
        {
            Time_TrackingPortClient oHRClient = null;
            try
            {
                oHRClient = new Time_TrackingPortClient();
                oHRClient.Endpoint.Address = new EndpointAddress(psEndpointAddress);
                oHRClient.ClientCredentials.UserName.UserName = psUsername;
                oHRClient.ClientCredentials.UserName.Password = psPassword;
            }
            catch (Exception ex)
            {
            }
            return oHRClient;
        }



    }
}
