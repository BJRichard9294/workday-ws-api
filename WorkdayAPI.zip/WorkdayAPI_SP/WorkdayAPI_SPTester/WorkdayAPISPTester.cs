﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WorkdayIntegrationEntities;
using WorkdayAPI_SP;
using WorkdayAPI.HumanResources;
using System.Net;

namespace WorkdayAPI_SPTester
{
    public partial class frmWorkdayAPISPTester : Form
    {
        private HumanResourcesAPI_SP oWDWorker;
        public frmWorkdayAPISPTester()
        {
            InitializeComponent();
            string sEndpoint = System.Configuration.ConfigurationSettings.AppSettings["WorkdayWebserviceEndpointSandbox"];
            string sUser = System.Configuration.ConfigurationSettings.AppSettings["WorkdayAccountUsername"];
            string sPass = System.Configuration.ConfigurationSettings.AppSettings["WorkdayAccountPassword"];

            oWDWorker = new HumanResourcesAPI_SP(sEndpoint, sUser, sPass, MyHandleErr);


        }

        private void btnDoTest_Click(object sender, EventArgs e)
        {


          List<WorkdayWorkerInformation> oWDInfoList = new List<WorkdayWorkerInformation>();

      oWDWorker.GetWorkersInformation(ref oWDInfoList, false, 1, 50,DateTime.Now, WorkdayAPI.HumanResourcesAPI.DateSelectionType.Effective);

            //DateTime? oEffFrom = DateTime.Now.AddDays(-180);
            //DateTime? oEffThrough = DateTime.Now;
            //oWDWorker.GetWorkersTransactions(ref oWDInfoList, false, 1, 500, oEffFrom, oEffThrough);







        }



        private void btnGetWorkerDocs_Click(object sender, EventArgs e)
        {
            oWDWorker.GetSaveWorkersDocuments("C:\\Temp\\Workday\\Documents\\");

        }


        private void MyHandleErr(Exception ex)
        {

            string sMessage = ex.Message;
            string sSource = ex.Source;
            string sTargetSite = ex.TargetSite.ToString();
            string sStackTrace = ex.StackTrace;
            if ((ex.InnerException != null))
            {
                if (!string.IsNullOrEmpty(ex.InnerException.Message))
                    sMessage += "\n\nInner Exception Message - " + ex.InnerException.Message;
                if (!string.IsNullOrEmpty(ex.InnerException.Source))
                    sSource += "\n\nInner Exception Source - " + ex.InnerException.Source;
                if (!string.IsNullOrEmpty(ex.InnerException.TargetSite.ToString()))
                    sTargetSite += "\n\nInner Exception Target Site - " + ex.InnerException.TargetSite.ToString();
                if (!string.IsNullOrEmpty(ex.InnerException.StackTrace))
                    sStackTrace = "\n\nInner Exception Stack Trace - " + ex.InnerException.StackTrace;
            }

            txtResults.Text = "Error Information - " + DateTime.Now + "\n\nMESSAGE - " + sMessage + "\n\nSOURCE - " + sSource + "\n\nTARGET SITE - " + sTargetSite + "\n\nSTACK TRACE - " + sStackTrace;

            //            Console.WriteLine(sErrorDetails);
        }

    }
}
