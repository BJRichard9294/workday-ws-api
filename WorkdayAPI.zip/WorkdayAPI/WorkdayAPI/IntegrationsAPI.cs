﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WorkdayAPI.Integrations;

namespace WorkdayAPI
{
    class IntegrationsAPI
    {

        private const string pcsVersion = "v26.2";
        private string psEndpointAddress, psUsername, psPassword;
        private Workday_Common_HeaderType oCommonHeader = null;

        /// <summary>
        /// Class constructor.  Must supply the Endpoint Address and login Username/Password
        /// </summary>
        /// <param name="sEndpointAddress"></param>
        /// <param name="sUsername"></param>
        /// <param name="sPassword"></param>
        public IntegrationsAPI(string sEndpointAddress, string sUsername, string sPassword)
        {
            psEndpointAddress = sEndpointAddress;
            psUsername = sUsername;
            psPassword = sPassword;
            oCommonHeader = new Workday_Common_HeaderType();
            oCommonHeader.Include_Reference_Descriptors_In_Response = false;
            oCommonHeader.Include_Reference_Descriptors_In_ResponseSpecified = true;
        }

        private IntegrationsPortClient GetPortClient()
        {
            IntegrationsPortClient oIntClient = null;
            oIntClient = new IntegrationsPortClient();
            oIntClient.Endpoint.Address = new EndpointAddress(psEndpointAddress);
            oIntClient.ClientCredentials.UserName.UserName = psUsername;
            oIntClient.ClientCredentials.UserName.Password = psPassword;
            return oIntClient;
        }

        public void Launch_EIB(string sIntegrationSystemID)
        {
            IntegrationsPortClient oIntClient = GetPortClient();

            Integration_System__Audited_ObjectIDType[] oAuditID = new Integration_System__Audited_ObjectIDType[1];
            oAuditID[0] = new Integration_System__Audited_ObjectIDType();
            oAuditID[0].type = "Integration_System_ID";
            oAuditID[0].Value = sIntegrationSystemID;

            Integration_System__Audited_ObjectType[] oAudit = new Integration_System__Audited_ObjectType[1];
            oAudit[0] = new Integration_System__Audited_ObjectType();
            oAudit[0].ID = oAuditID;



            Launch_EIB_RequestType oRequest = null;

            Launch_EIB_ResponseType oResponse = oIntClient.Launch_EIB(oCommonHeader, oRequest);
            
        }

    // Below is example from Workday Community

    //public string[] runEIBIntegrationNoPrompts(string intID)
    //    {
    //        string IntEventID = "";
    //        string IntEventIDtype = "";
    //        //string IntStat = "";

    //        IntegrationsPortClient IntClient = new IntegrationsPortClient();

    //        IntClient.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["TestingName"].ToString() + "@" + ConfigurationManager.AppSettings["Tenant"].ToString();
    //        IntClient.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["TestingpWord"].ToString();
           

    //        Launch_EIB_RequestType IntRequest = new Launch_EIB_RequestType();
    //        IntRequest.version = ConfigurationManager.AppSettings["Version"].ToString();
           
    //        IntRequest.Integration_System_Reference = new Integrations.Integration_System__Audited_ObjectType();
    //        IntRequest.Integration_System_Reference.ID = new Integrations.Integration_System__Audited_ObjectIDType[1];
    //        IntRequest.Integration_System_Reference.ID[0] = new Integrations.Integration_System__Audited_ObjectIDType() { type = "Integration_System_ID", Value = intID };

    //        //Launch_EIBInput lReq = new Launch_EIBInput(IntRequest);

    //        Launch_EIBOutput resp = new Launch_EIBOutput();
    //        resp.Launch_EIB_Response = IntClient.Launch_EIB(IntRequest);
            
    //        IntEventID = resp.Launch_EIB_Response.Integration_Event.Integration_Event_Reference.ID[0].Value.ToString();
    //        IntEventIDtype = resp.Launch_EIB_Response.Integration_Event.Integration_Event_Reference.ID[0].type.ToString();

    //        string[] intEvent = new string[2];
    //        intEvent[0] = IntEventID;
    //        intEvent[1] = IntEventIDtype;

            
    //        //TotalRowsTB.Text = IntEventIDtype;
    //        //ItemPerRowTB.Text = IntEventID;

    //        //IntStat = IntStatus(IntEventIDtype, IntEventID, Uname, Pword);

    //        return intEvent;
    //    }

    }
}
