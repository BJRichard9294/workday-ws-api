﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorkdayAPI;
using System.ServiceModel;
using WorkdayAPI.HumanResources;
using System.ServiceModel.Channels;
using System.Xml;

namespace WorkdayAPI
{
     class ServiceUtils
    {
        public static Binding GetCustomBinding()
        {
            Binding oCustBinding = null;

            SecurityBindingElement oSecBinding = SecurityBindingElement.CreateUserNameOverTransportBindingElement();
            oSecBinding.IncludeTimestamp = false;
            const int iIntLimit = Int32.MaxValue;
            // TODO - make timeout period user configurable
            var timeout = TimeSpan.FromMinutes(2);

            oCustBinding = new CustomBinding(
                oSecBinding,
                new TextMessageEncodingBindingElement(MessageVersion.Soap11, Encoding.UTF8)
                {
                    ReaderQuotas = new XmlDictionaryReaderQuotas
                    {
                        MaxDepth = iIntLimit,
                        MaxStringContentLength = iIntLimit,
                        MaxArrayLength = iIntLimit,
                        MaxBytesPerRead = iIntLimit,
                        MaxNameTableCharCount = iIntLimit
                    }
                },
                new HttpsTransportBindingElement
                {
                    MaxBufferPoolSize = iIntLimit,
                    MaxReceivedMessageSize = iIntLimit,
                    MaxBufferSize = iIntLimit,
                    Realm = string.Empty
                })
            {
                SendTimeout = timeout,
                ReceiveTimeout = timeout
            };
            return oCustBinding;
        }


    }
}
