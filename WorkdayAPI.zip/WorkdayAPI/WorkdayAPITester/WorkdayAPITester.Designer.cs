﻿namespace WorkdayAPITester
{
    partial class WorkdayAPITester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorkdayAPITester));
      this.btnGetWorkers = new System.Windows.Forms.Button();
      this.txtResults = new System.Windows.Forms.TextBox();
      this.txtEmployeeID = new System.Windows.Forms.TextBox();
      this.txtUpdateDataTo = new System.Windows.Forms.TextBox();
      this.txtPageSize = new System.Windows.Forms.TextBox();
      this.txtPageNumber = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.btnGetWorkerData = new System.Windows.Forms.Button();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.cboGetDataType = new System.Windows.Forms.ComboBox();
      this.label8 = new System.Windows.Forms.Label();
      this.dtDateFrom = new System.Windows.Forms.DateTimePicker();
      this.dtDateThrough = new System.Windows.Forms.DateTimePicker();
      this.label9 = new System.Windows.Forms.Label();
      this.cboUpdateDataType = new System.Windows.Forms.ComboBox();
      this.btnUpdateData = new System.Windows.Forms.Button();
      this.chkUpdatePrimary = new System.Windows.Forms.CheckBox();
      this.chkCreateNew = new System.Windows.Forms.CheckBox();
      this.chkMakePublic = new System.Windows.Forms.CheckBox();
      this.btnRunDev = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnGetWorkers
      // 
      this.btnGetWorkers.Location = new System.Drawing.Point(685, 52);
      this.btnGetWorkers.Name = "btnGetWorkers";
      this.btnGetWorkers.Size = new System.Drawing.Size(111, 23);
      this.btnGetWorkers.TabIndex = 0;
      this.btnGetWorkers.Text = "Get Workers";
      this.btnGetWorkers.UseVisualStyleBackColor = true;
      this.btnGetWorkers.Click += new System.EventHandler(this.btnGetWorkers_Click);
      // 
      // txtResults
      // 
      this.txtResults.Location = new System.Drawing.Point(12, 125);
      this.txtResults.Multiline = true;
      this.txtResults.Name = "txtResults";
      this.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtResults.Size = new System.Drawing.Size(784, 336);
      this.txtResults.TabIndex = 3;
      // 
      // txtEmployeeID
      // 
      this.txtEmployeeID.Location = new System.Drawing.Point(11, 27);
      this.txtEmployeeID.Name = "txtEmployeeID";
      this.txtEmployeeID.Size = new System.Drawing.Size(83, 20);
      this.txtEmployeeID.TabIndex = 6;
      // 
      // txtUpdateDataTo
      // 
      this.txtUpdateDataTo.Location = new System.Drawing.Point(522, 28);
      this.txtUpdateDataTo.Name = "txtUpdateDataTo";
      this.txtUpdateDataTo.Size = new System.Drawing.Size(100, 20);
      this.txtUpdateDataTo.TabIndex = 7;
      // 
      // txtPageSize
      // 
      this.txtPageSize.Location = new System.Drawing.Point(685, 28);
      this.txtPageSize.Name = "txtPageSize";
      this.txtPageSize.Size = new System.Drawing.Size(57, 20);
      this.txtPageSize.TabIndex = 8;
      this.txtPageSize.Text = "10";
      this.txtPageSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // txtPageNumber
      // 
      this.txtPageNumber.Location = new System.Drawing.Point(748, 28);
      this.txtPageNumber.Name = "txtPageNumber";
      this.txtPageNumber.Size = new System.Drawing.Size(48, 20);
      this.txtPageNumber.TabIndex = 9;
      this.txtPageNumber.Text = "1";
      this.txtPageNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(12, 109);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(42, 13);
      this.label1.TabIndex = 10;
      this.label1.Text = "Results";
      // 
      // btnGetWorkerData
      // 
      this.btnGetWorkerData.Location = new System.Drawing.Point(216, 25);
      this.btnGetWorkerData.Name = "btnGetWorkerData";
      this.btnGetWorkerData.Size = new System.Drawing.Size(83, 23);
      this.btnGetWorkerData.TabIndex = 11;
      this.btnGetWorkerData.Text = "Get Data";
      this.btnGetWorkerData.UseVisualStyleBackColor = true;
      this.btnGetWorkerData.Click += new System.EventHandler(this.btnGetWorker_Click);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(745, 9);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(42, 13);
      this.label2.TabIndex = 12;
      this.label2.Text = "Page #";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(682, 9);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(55, 13);
      this.label3.TabIndex = 13;
      this.label3.Text = "Page Size";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(519, 9);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(88, 13);
      this.label4.TabIndex = 14;
      this.label4.Text = "Update Value To";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(394, 9);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(95, 13);
      this.label5.TabIndex = 15;
      this.label5.Text = "Update Data Type";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(9, 9);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(67, 13);
      this.label6.TabIndex = 16;
      this.label6.Text = "Employee ID";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(107, 9);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(77, 13);
      this.label7.TabIndex = 18;
      this.label7.Text = "Get Data Type";
      // 
      // cboGetDataType
      // 
      this.cboGetDataType.FormattingEnabled = true;
      this.cboGetDataType.Items.AddRange(new object[] {
            "Worker",
            "Employee",
            "Profile",
            "Event History",
            "Account",
            "Related Persons"});
      this.cboGetDataType.Location = new System.Drawing.Point(110, 27);
      this.cboGetDataType.Name = "cboGetDataType";
      this.cboGetDataType.Size = new System.Drawing.Size(100, 21);
      this.cboGetDataType.TabIndex = 19;
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(12, 57);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(56, 13);
      this.label8.TabIndex = 20;
      this.label8.Text = "Date From";
      // 
      // dtDateFrom
      // 
      this.dtDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtDateFrom.Location = new System.Drawing.Point(11, 73);
      this.dtDateFrom.Name = "dtDateFrom";
      this.dtDateFrom.Size = new System.Drawing.Size(87, 20);
      this.dtDateFrom.TabIndex = 21;
      // 
      // dtDateThrough
      // 
      this.dtDateThrough.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtDateThrough.Location = new System.Drawing.Point(110, 73);
      this.dtDateThrough.Name = "dtDateThrough";
      this.dtDateThrough.Size = new System.Drawing.Size(87, 20);
      this.dtDateThrough.TabIndex = 22;
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(107, 57);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(73, 13);
      this.label9.TabIndex = 23;
      this.label9.Text = "Date Through";
      // 
      // cboUpdateDataType
      // 
      this.cboUpdateDataType.FormattingEnabled = true;
      this.cboUpdateDataType.Items.AddRange(new object[] {
            "Phone",
            "Email",
            "Username"});
      this.cboUpdateDataType.Location = new System.Drawing.Point(397, 27);
      this.cboUpdateDataType.Name = "cboUpdateDataType";
      this.cboUpdateDataType.Size = new System.Drawing.Size(111, 21);
      this.cboUpdateDataType.TabIndex = 25;
      // 
      // btnUpdateData
      // 
      this.btnUpdateData.Location = new System.Drawing.Point(522, 52);
      this.btnUpdateData.Name = "btnUpdateData";
      this.btnUpdateData.Size = new System.Drawing.Size(100, 23);
      this.btnUpdateData.TabIndex = 26;
      this.btnUpdateData.Text = "Update Data";
      this.btnUpdateData.UseVisualStyleBackColor = true;
      this.btnUpdateData.Click += new System.EventHandler(this.btnUpdateData_Click);
      // 
      // chkUpdatePrimary
      // 
      this.chkUpdatePrimary.AutoSize = true;
      this.chkUpdatePrimary.Location = new System.Drawing.Point(397, 52);
      this.chkUpdatePrimary.Name = "chkUpdatePrimary";
      this.chkUpdatePrimary.Size = new System.Drawing.Size(104, 17);
      this.chkUpdatePrimary.TabIndex = 27;
      this.chkUpdatePrimary.Text = "Update Primary?";
      this.chkUpdatePrimary.UseVisualStyleBackColor = true;
      // 
      // chkCreateNew
      // 
      this.chkCreateNew.AutoSize = true;
      this.chkCreateNew.Location = new System.Drawing.Point(397, 73);
      this.chkCreateNew.Name = "chkCreateNew";
      this.chkCreateNew.Size = new System.Drawing.Size(88, 17);
      this.chkCreateNew.TabIndex = 28;
      this.chkCreateNew.Text = "Create New?";
      this.chkCreateNew.UseVisualStyleBackColor = true;
      // 
      // chkMakePublic
      // 
      this.chkMakePublic.AutoSize = true;
      this.chkMakePublic.Location = new System.Drawing.Point(397, 96);
      this.chkMakePublic.Name = "chkMakePublic";
      this.chkMakePublic.Size = new System.Drawing.Size(91, 17);
      this.chkMakePublic.TabIndex = 30;
      this.chkMakePublic.Text = "Make Public?";
      this.chkMakePublic.UseVisualStyleBackColor = true;
      // 
      // btnRunDev
      // 
      this.btnRunDev.Location = new System.Drawing.Point(713, 96);
      this.btnRunDev.Name = "btnRunDev";
      this.btnRunDev.Size = new System.Drawing.Size(83, 23);
      this.btnRunDev.TabIndex = 31;
      this.btnRunDev.Text = "Run Dev";
      this.btnRunDev.UseVisualStyleBackColor = true;
      this.btnRunDev.Click += new System.EventHandler(this.btnRunDev_Click);
      // 
      // WorkdayAPITester
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(808, 473);
      this.Controls.Add(this.btnRunDev);
      this.Controls.Add(this.chkMakePublic);
      this.Controls.Add(this.chkCreateNew);
      this.Controls.Add(this.chkUpdatePrimary);
      this.Controls.Add(this.btnUpdateData);
      this.Controls.Add(this.cboUpdateDataType);
      this.Controls.Add(this.label9);
      this.Controls.Add(this.dtDateThrough);
      this.Controls.Add(this.dtDateFrom);
      this.Controls.Add(this.label8);
      this.Controls.Add(this.cboGetDataType);
      this.Controls.Add(this.label7);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.btnGetWorkerData);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.txtPageNumber);
      this.Controls.Add(this.txtPageSize);
      this.Controls.Add(this.txtUpdateDataTo);
      this.Controls.Add(this.txtEmployeeID);
      this.Controls.Add(this.txtResults);
      this.Controls.Add(this.btnGetWorkers);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "WorkdayAPITester";
      this.Text = "Workday API Tester";
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGetWorkers;
        private System.Windows.Forms.TextBox txtResults;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.TextBox txtUpdateDataTo;
        private System.Windows.Forms.TextBox txtPageSize;
        private System.Windows.Forms.TextBox txtPageNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGetWorkerData;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboGetDataType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtDateFrom;
        private System.Windows.Forms.DateTimePicker dtDateThrough;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboUpdateDataType;
        private System.Windows.Forms.Button btnUpdateData;
        private System.Windows.Forms.CheckBox chkUpdatePrimary;
        private System.Windows.Forms.CheckBox chkCreateNew;
        private System.Windows.Forms.CheckBox chkMakePublic;
    private System.Windows.Forms.Button btnRunDev;
  }
}

