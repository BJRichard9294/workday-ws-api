﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using WorkdayAPI.HumanResources;

namespace WorkdayAPI
{
  public class HumanResourcesAPI
  {
    // This API is derived from the WSDL for the Human Resources Web Services https://community.workday.com/custom/developer/API/Human_Resources/v26.2/Human_Resources.html 

    //  IMPORTANT - This version number must match the version of the WSDL used to create the Web Service classes!
    private const string pcsVersion = "v26.2";
    private string psEndpointAddress, psUsername, psPassword;
    private Workday_Common_HeaderType oCommonHeader = null;
    public bool bServiceBindingInAppConfig = false;

    private const int MAX_PAGES_TO_REQUEST = 50;
    private const int MAX_PAGE_SIZE_TO_REQUEST = 999;

    public enum ContactType { WORK, HOME }
    public enum PhoneDeviceType { Landline, Mobile, Fax, Pager }
    public enum DateSelectionType { DataEntry, Effective }
    private enum ContactUpdateType { EMAIL, PHONE, ADDRESS }

    public Human_ResourcesPortClient oHRClient = null;

    public delegate void ErrHandler(Exception ex);
    public ErrHandler oErrHandler = null;

    /// <summary>
    /// Class constructor.  Must supply the Endpoint Address and login Username/Password
    /// </summary>
    /// <param name="sEndpointAddress">Workday web service endpoint address</param>
    /// <param name="sUsername"></param>
    /// <param name="sPassword"></param>
    /// <param name="oInErrHandler">User supplied error handler</param>
    public HumanResourcesAPI(string sEndpointAddress, string sUsername, string sPassword, ErrHandler oInErrHandler)
    {
      psEndpointAddress = sEndpointAddress;
      psUsername = sUsername;
      psPassword = sPassword;
      oCommonHeader = new Workday_Common_HeaderType();
      oCommonHeader.Include_Reference_Descriptors_In_Response = false;
      oCommonHeader.Include_Reference_Descriptors_In_ResponseSpecified = true;
      oErrHandler = oInErrHandler;
      oHRClient = GetPortClient();
    }

    public void HandleErr(Exception ex)
    {
      oErrHandler.Invoke(ex);
    }

    private Human_ResourcesPortClient GetPortClient()
    {
      try
      {
        EndpointAddress oEndpoint = new EndpointAddress(psEndpointAddress);
        if (bServiceBindingInAppConfig)
        {
          oHRClient = new Human_ResourcesPortClient();
          oHRClient.Endpoint.Address = new EndpointAddress(psEndpointAddress);
        }
        else
        {
          oHRClient = new Human_ResourcesPortClient(ServiceUtils.GetCustomBinding(), oEndpoint);
        }
        oHRClient.ClientCredentials.UserName.UserName = psUsername;
        oHRClient.ClientCredentials.UserName.Password = psPassword;
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oHRClient;
    }

    #region 'Get_Workers General Functions'


    /// <summary>
    /// Returns just the Worker_DataType of the Get_Workers_ResponseType for the supplied sEmployeeID
    /// </summary>
    /// <param name="sEmployeeID"></param>
    /// <returns></returns>
    public Worker_DataType GetWorkerData(string sEmployeeID, bool bIsContingentWorker, Get_Workers_RequestType oRequest, Response_FilterType oRespFilter, Worker_Response_GroupType oRespGroup)
    {
      Worker_DataType oWorkerData = null;
      try
      {
        Get_Workers_ResponseType oWorker = GetWorker(sEmployeeID, bIsContingentWorker, oRequest, oRespFilter, oRespGroup);
        if (oWorker != null) { oWorkerData = oWorker.Response_Data[0].Worker_Data; }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorkerData;
    }

    public Worker_DataType GetWorkerData(string sEmployeeID, bool bIsContingentWorker)
    {
      return GetWorkerData(sEmployeeID, false, null, null, null);
    }

    public Worker_DataType GetWorkerData(string sEmployeeID)
    {
      return GetWorkerData(sEmployeeID, false, null, null, null);
    }

    public void SetWorkerRequestTypeForEmployee(string sEmployeeID, bool bIsContingentWorker, ref Get_Workers_RequestType oRequest)
    {
      if (oRequest == null)
      {
        oRequest = CreateDefaultGetWorkersRequest();
      }
      WorkerObjectIDType[] oWkObjIDType = new WorkerObjectIDType[1];
      oWkObjIDType[0] = new WorkerObjectIDType();
      if (bIsContingentWorker)
      {
        oWkObjIDType[0].type = "Contingent_Worker_ID";
      }
      else
      {
        oWkObjIDType[0].type = "Employee_ID";
      }
      oWkObjIDType[0].Value = sEmployeeID;

      WorkerObjectType[] oWorkerObj = new WorkerObjectType[1];
      oWorkerObj[0] = new WorkerObjectType();
      oWorkerObj[0].ID = oWkObjIDType;

      Worker_Request_ReferencesType oReqRefType = new Worker_Request_ReferencesType();
      oReqRefType.Worker_Reference = oWorkerObj;
      oRequest.Request_References = oReqRefType;
    }

    public void SetWorkerResponseTypeForDateSelection(DateSelectionType eDateSelectionType, DateTime dDateSelection, ref Response_FilterType oRespFilter)
    {
      if (oRespFilter == null) { oRespFilter = new Response_FilterType(); }
      if (eDateSelectionType == DateSelectionType.DataEntry)
      {
        oRespFilter.As_Of_Entry_DateTime = dDateSelection;
        oRespFilter.As_Of_Entry_DateTimeSpecified = true;
      }
      else
      {
        oRespFilter.As_Of_Effective_Date = dDateSelection;
        oRespFilter.As_Of_Effective_DateSpecified = true;
      }
    }

    public void SetWorkerResponseTypeForPaging(int iResponseFilterPageSize, int iRespFilterPageNumber, ref Response_FilterType oRespFilter)
    {
      if (oRespFilter == null) { oRespFilter = new Response_FilterType(); }
      if (iResponseFilterPageSize > 0)
      {
        oRespFilter.Count = iResponseFilterPageSize;
        oRespFilter.CountSpecified = true;
        if (iRespFilterPageNumber > 0)
        {
          oRespFilter.Page = iRespFilterPageNumber;
          oRespFilter.PageSpecified = true;
        }
      }
    }

    /// <summary>
    /// Returns the whole response object (Get_Workers_ResponseType) for the supplied sEmployeeID
    /// </summary>
    /// <param name="string sEmployeeID"></param>
    /// <returns>Get_Workers_ResponseType</returns>
    public Get_Workers_ResponseType GetWorker(string sEmployeeID, bool bIsContingentWorker, Get_Workers_RequestType oRequest, Response_FilterType oRespFilter, Worker_Response_GroupType oRespGroup)
    {
      Get_Workers_ResponseType oWorker = null;
      try
      {
        SetWorkerRequestTypeForEmployee(sEmployeeID, bIsContingentWorker, ref oRequest);
        oWorker = GetWorkers(oRequest, oRespFilter, oRespGroup);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorker;
    }

    public Get_Workers_ResponseType GetWorker(string sEmployeeID, bool bIsContingentWorker, DateSelectionType eDateSelectionType, DateTime dDateSelection, Get_Workers_RequestType oRequest, Response_FilterType oRespFilter, Worker_Response_GroupType oRespGroup)
    {
      Get_Workers_ResponseType oWorker = null;
      try
      {
        SetWorkerRequestTypeForEmployee(sEmployeeID, bIsContingentWorker, ref oRequest);
        SetWorkerResponseTypeForDateSelection(eDateSelectionType, dDateSelection, ref oRespFilter);
        oWorker = GetWorkers(oRequest, oRespFilter, oRespGroup);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorker;
    }

    public Get_Workers_ResponseType GetWorker(string sEmployeeID, bool bIsContingentWorker)
    {
      return GetWorker(sEmployeeID, bIsContingentWorker, null, null, null);
    }

    /// <summary>
    /// Base function for getting Worker Data that supports paging.
    /// </summary>
    /// <param name="bUseAsOfEffectiveDate"></param>
    /// <param name="iResponseFilterPageSize"></param>
    /// <param name="iRespFilterPageNumber"></param>
    /// <returns>Get_Workers_ResponseType</returns>
    public Get_Workers_ResponseType GetWorkers(DateSelectionType eDateSelectionType, DateTime dDateSelection, int iResponseFilterPageSize, int iRespFilterPageNumber, Get_Workers_RequestType oRequest, Response_FilterType oRespFilter, Worker_Response_GroupType oRespGroup)
    {
      Get_Workers_ResponseType oWorkers = null;
      try
      {
        SetWorkerResponseTypeForDateSelection(eDateSelectionType, dDateSelection, ref oRespFilter);
        SetWorkerResponseTypeForPaging(iResponseFilterPageSize, iRespFilterPageNumber, ref oRespFilter);
        oWorkers = GetWorkers(oRequest, oRespFilter, oRespGroup);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorkers;
    }

    public Get_Workers_ResponseType GetWorkers(DateSelectionType eDateSelectionType, DateTime dDateSelection, int iResponseFilterPageSize, int iRespFilterPageNumber)
    {
      return GetWorkers(eDateSelectionType, dDateSelection, iResponseFilterPageSize, iRespFilterPageNumber, null, null, null);
    }

    /// <summary>
    /// Base function for getting worker data.  Can optionally supply the Get_Workers_RequestType, Response_FilterType, and Worker_Response_GroupType.
    /// </summary>
    /// <param name="oRequest"></param>
    /// <param name="oRespFilter"></param>
    /// <param name="oRespGroup"></param>
    /// <returns></returns>
    public Get_Workers_ResponseType GetWorkers(Get_Workers_RequestType oRequest, Response_FilterType oRespFilter, Worker_Response_GroupType oRespGroup)
    {
      Get_Workers_ResponseType oWorkers = null;
      try
      {
        if (oRequest == null) { oRequest = CreateDefaultGetWorkersRequest(); }
        if (oRespFilter == null) { oRespFilter = CreateDefaultGetWorkersResponseFilter(); }
        if (oRespGroup == null) { oRespGroup = CreateGetWorkersResponseGroupAllItems(true); }
        //                if (oRespGroup == null) { oRespGroup = CreateDefaultGetWorkersResponseGroup(); }

        oRequest.Response_Filter = oRespFilter;
        oRequest.Response_Group = oRespGroup;
        oRequest.version = pcsVersion;
        oWorkers = oHRClient.Get_Workers(oCommonHeader, oRequest);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorkers;
    }

    public Worker_ProfileType GetWorkerProfile(string sEmployeeID, DateTime dAsOfMoment)
    {
      Worker_ProfileType oWorkerProfile = null;
      try
      {
        Worker_ReferenceType oWorker = new Worker_ReferenceType();
        if (CreateWorkerReference(sEmployeeID, ref oWorker))
        {
          Worker_Profile_GetType oWorkerProfileGet = new Worker_Profile_GetType();
          oWorkerProfileGet.Worker_Reference = oWorker;
          oWorkerProfileGet.As_Of_Moment = dAsOfMoment;
          oWorkerProfileGet.As_Of_MomentSpecified = true;

          oWorkerProfile = oHRClient.Get_Worker_Profile(oCommonHeader, oWorkerProfileGet);
        }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorkerProfile;
    }

    public Worker_Event_HistoryType GetWorkerEventHistory(string sEmployeeID, DateTime dFromDate, DateTime dThroughDate, DateSelectionType eDateRangeType)
    {
      Worker_Event_HistoryType oWorkerEvents = null;

      // BJR TODO - Do input date range validation.

      try
      {
        Worker_ReferenceType oWorker = new Worker_ReferenceType();
        if (CreateWorkerReference(sEmployeeID, ref oWorker))
        {

          Worker_Event_History_GetType oEventHistoryGet = new Worker_Event_History_GetType();
          oEventHistoryGet.Worker_Reference = oWorker;

          Effective_And_Updated_DateTime_DataType oEffUpdDateTime = new Effective_And_Updated_DateTime_DataType();
          if (eDateRangeType == DateSelectionType.DataEntry)
          {
            oEffUpdDateTime.Updated_From = dFromDate;
            oEffUpdDateTime.Updated_FromSpecified = true;
            oEffUpdDateTime.Updated_Through = dThroughDate;
            oEffUpdDateTime.Updated_ThroughSpecified = true;
          }
          else
          {
            oEffUpdDateTime.Effective_From = dFromDate;
            oEffUpdDateTime.Effective_FromSpecified = true;
            oEffUpdDateTime.Effective_Through = dThroughDate;
            oEffUpdDateTime.Effective_ThroughSpecified = true;
          }

          oWorkerEvents = oHRClient.Get_Worker_Event_History(oCommonHeader, oEventHistoryGet);
        }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorkerEvents;
    }

    public Get_Workers_RequestType CreateDefaultGetWorkersRequest()
    {
      Get_Workers_RequestType CreateDefaultGetWorkersRequest = new Get_Workers_RequestType();
      CreateDefaultGetWorkersRequest.version = pcsVersion;
      return CreateDefaultGetWorkersRequest;
    }
    private Response_FilterType CreateDefaultGetWorkersResponseFilter()
    {
      Response_FilterType oRespFilter = new Response_FilterType();
      oRespFilter.As_Of_Entry_DateTime = DateTime.Now.ToUniversalTime();
      oRespFilter.As_Of_Entry_DateTimeSpecified = true;
      return oRespFilter;
    }

    public Worker_Response_GroupType CreateDefaultGetWorkersResponseGroup()
    {
      Worker_Response_GroupType oRespGroup = new Worker_Response_GroupType();
      oRespGroup.Include_Reference = true;
      oRespGroup.Include_Personal_Information = true;
      oRespGroup.Include_Compensation = true;
      oRespGroup.Include_Benefit_Enrollments = true;
      oRespGroup.Include_Employment_Information = true;
      oRespGroup.Include_User_Account = true;
      oRespGroup.Include_Related_Persons = true;
      oRespGroup.Include_Roles = true;

      oRespGroup.Include_ReferenceSpecified = true;
      oRespGroup.Include_Personal_InformationSpecified = true;
      oRespGroup.Include_CompensationSpecified = true;
      oRespGroup.Include_Benefit_EnrollmentsSpecified = true;
      oRespGroup.Include_Employment_InformationSpecified = true;
      oRespGroup.Include_User_AccountSpecified = true;
      oRespGroup.Include_Related_PersonsSpecified = true;
      oRespGroup.Include_RolesSpecified = true;
      return oRespGroup;
    }
    public Worker_Response_GroupType CreateGetWorkersResponseGroupAllItems(bool bSetToInclude)
    {
      Worker_Response_GroupType oRespGroup = new Worker_Response_GroupType();
      oRespGroup.Include_Account_Provisioning = bSetToInclude;
      oRespGroup.Include_Additional_Jobs = bSetToInclude;
      oRespGroup.Include_Background_Check_Data = bSetToInclude;
      oRespGroup.Include_Benefit_Eligibility = bSetToInclude;
      oRespGroup.Include_Benefit_Enrollments = bSetToInclude;
      oRespGroup.Include_Career = bSetToInclude;
      oRespGroup.Include_Development_Items = bSetToInclude;
      oRespGroup.Include_Employee_Contract_Data = bSetToInclude;
      oRespGroup.Include_Employee_Review = bSetToInclude;
      oRespGroup.Include_Management_Chain_Data = bSetToInclude;
      oRespGroup.Include_Organizations = bSetToInclude;
      oRespGroup.Include_Qualifications = bSetToInclude;
      oRespGroup.Include_Skills = bSetToInclude;
      oRespGroup.Include_Worker_Documents = bSetToInclude;

      oRespGroup.Include_Reference = bSetToInclude;
      oRespGroup.Include_Personal_Information = bSetToInclude;
      oRespGroup.Include_Compensation = bSetToInclude;
      oRespGroup.Include_Employment_Information = bSetToInclude;
      oRespGroup.Include_User_Account = bSetToInclude;
      oRespGroup.Include_Related_Persons = bSetToInclude;
      oRespGroup.Include_Roles = bSetToInclude;

      oRespGroup.Include_Account_ProvisioningSpecified = true;
      oRespGroup.Include_Additional_JobsSpecified = true;
      oRespGroup.Include_Background_Check_DataSpecified = true;
      oRespGroup.Include_Benefit_EligibilitySpecified = true;
      oRespGroup.Include_Benefit_EnrollmentsSpecified = true;
      oRespGroup.Include_CareerSpecified = true;
      oRespGroup.Include_Development_ItemsSpecified = true;
      oRespGroup.Include_Employee_Contract_DataSpecified = true;
      oRespGroup.Include_Employee_ReviewSpecified = true;
      oRespGroup.Include_Management_Chain_DataSpecified = true;
      oRespGroup.Include_OrganizationsSpecified = true;
      oRespGroup.Include_QualificationsSpecified = true;
      oRespGroup.Include_SkillsSpecified = true;
      oRespGroup.Include_Worker_DocumentsSpecified = true;

      oRespGroup.Include_ReferenceSpecified = true;
      oRespGroup.Include_Personal_InformationSpecified = true;
      oRespGroup.Include_CompensationSpecified = true;
      oRespGroup.Include_Employment_InformationSpecified = true;
      oRespGroup.Include_User_AccountSpecified = true;
      oRespGroup.Include_Related_PersonsSpecified = true;
      oRespGroup.Include_RolesSpecified = true;
      return oRespGroup;
    }

    public Worker_Response_GroupType CreateGetWorkersResponseGroup(bool bInclude_Account_Provisioning, bool bInclude_Additional_Jobs, bool bInclude_Background_Check_Data, bool bInclude_Benefit_Eligibility,
        bool bInclude_Benefit_Enrollments, bool bInclude_Career, bool bInclude_Development_Items, bool bInclude_Employee_Contract_Data, bool bInclude_Employee_Review, bool bInclude_Management_Chain_Data,
        bool bInclude_Organizations, bool bInclude_Qualifications, bool bInclude_Skills, bool bInclude_Worker_Documents, bool bInclude_Reference, bool bInclude_Personal_Information,
        bool bInclude_Compensation, bool bInclude_Employment_Information, bool bInclude_User_Account, bool bInclude_Related_Persons, bool bInclude_Roles)
    {
      Worker_Response_GroupType oRespGroup = new Worker_Response_GroupType();
      oRespGroup.Include_Account_Provisioning = bInclude_Account_Provisioning;
      oRespGroup.Include_Additional_Jobs = bInclude_Additional_Jobs;
      oRespGroup.Include_Background_Check_Data = bInclude_Background_Check_Data;
      oRespGroup.Include_Benefit_Eligibility = bInclude_Benefit_Eligibility;
      oRespGroup.Include_Benefit_Enrollments = bInclude_Benefit_Enrollments;
      oRespGroup.Include_Career = bInclude_Career;
      oRespGroup.Include_Development_Items = bInclude_Development_Items;
      oRespGroup.Include_Employee_Contract_Data = bInclude_Employee_Contract_Data;
      oRespGroup.Include_Employee_Review = bInclude_Employee_Review;
      oRespGroup.Include_Management_Chain_Data = bInclude_Management_Chain_Data;
      oRespGroup.Include_Organizations = bInclude_Organizations;
      oRespGroup.Include_Qualifications = bInclude_Qualifications;
      oRespGroup.Include_Skills = bInclude_Skills;
      oRespGroup.Include_Worker_Documents = bInclude_Worker_Documents;

      oRespGroup.Include_Reference = bInclude_Reference;
      oRespGroup.Include_Personal_Information = bInclude_Personal_Information;
      oRespGroup.Include_Compensation = bInclude_Compensation;
      oRespGroup.Include_Employment_Information = bInclude_Employment_Information;
      oRespGroup.Include_User_Account = bInclude_User_Account;
      oRespGroup.Include_Related_Persons = bInclude_Related_Persons;
      oRespGroup.Include_Roles = bInclude_Roles;

      oRespGroup.Include_Account_ProvisioningSpecified = bInclude_Account_Provisioning;
      oRespGroup.Include_Additional_JobsSpecified = bInclude_Additional_Jobs;
      oRespGroup.Include_Background_Check_DataSpecified = bInclude_Background_Check_Data;
      oRespGroup.Include_Benefit_EligibilitySpecified = bInclude_Benefit_Eligibility;
      oRespGroup.Include_Benefit_EnrollmentsSpecified = bInclude_Benefit_Enrollments;
      oRespGroup.Include_CareerSpecified = bInclude_Career;
      oRespGroup.Include_Development_ItemsSpecified = bInclude_Development_Items;
      oRespGroup.Include_Employee_Contract_DataSpecified = bInclude_Employee_Contract_Data;
      oRespGroup.Include_Employee_ReviewSpecified = bInclude_Employee_Review;
      oRespGroup.Include_Management_Chain_DataSpecified = bInclude_Management_Chain_Data;
      oRespGroup.Include_OrganizationsSpecified = bInclude_Organizations;
      oRespGroup.Include_QualificationsSpecified = bInclude_Qualifications;
      oRespGroup.Include_SkillsSpecified = bInclude_Skills;
      oRespGroup.Include_Worker_DocumentsSpecified = bInclude_Worker_Documents;

      oRespGroup.Include_ReferenceSpecified = bInclude_Reference;
      oRespGroup.Include_Personal_InformationSpecified = bInclude_Personal_Information;
      oRespGroup.Include_CompensationSpecified = bInclude_Compensation;
      oRespGroup.Include_Employment_InformationSpecified = bInclude_Employment_Information;
      oRespGroup.Include_User_AccountSpecified = bInclude_User_Account;
      oRespGroup.Include_Related_PersonsSpecified = bInclude_Related_Persons;
      oRespGroup.Include_RolesSpecified = bInclude_Roles;
      return oRespGroup;
    }

    #endregion

    #region 'Get_Employee Functions'
    public EmployeeType GetEmployee(string sEmployeeID, DateTime dAsOfMoment)
    {
      EmployeeType oEmployee = null;
      try
      {
        Employee_ReferenceType oEmployeeRef = new Employee_ReferenceType();
        if (CreateEmployeeReference(sEmployeeID, ref oEmployeeRef))
        {
          Employee_GetType oEmployeeGet = new Employee_GetType();
          oEmployeeGet.Employee_Reference = oEmployeeRef;
          oEmployeeGet.As_Of_Moment = dAsOfMoment;
          oEmployeeGet.As_Of_MomentSpecified = true;
          oEmployee = oHRClient.Get_Employee(oCommonHeader, oEmployeeGet);
        }

      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oEmployee;
    }

    public EmployeeType GetEmployee(string sEmployeeID)
    {
      return GetEmployee(sEmployeeID, DateTime.Now);
    }
    public Employee_Related_PersonsType GetEmployeeRelatedPersons(string sEmployeeID, DateTime dAsOfMoment)
    {
      // Human_ResourcesPortClient oHRClient = GetPortClient();
      Employee_Related_PersonsType oEmployeeRelatedPersons = null;
      try
      {
        Employee_ReferenceType oEmployeeRef = new Employee_ReferenceType();
        if (CreateEmployeeReference(sEmployeeID, ref oEmployeeRef))
        {
          Employee_Related_Persons_GetType oEmployeeGet = new Employee_Related_Persons_GetType();
          oEmployeeGet.Employee_Reference = oEmployeeRef;
          oEmployeeGet.As_Of_Moment = dAsOfMoment;
          oEmployeeGet.As_Of_MomentSpecified = true;
          oEmployeeRelatedPersons = oHRClient.Get_Employee_Related_Persons(oCommonHeader, oEmployeeGet);
        }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oEmployeeRelatedPersons;
    }
    public Employee_Related_PersonsType GetEmployeeRelatedPersons(string sEmployeeID)
    {
      return GetEmployeeRelatedPersons(sEmployeeID, DateTime.Now);
    }

    #endregion

    #region 'Workday_Account functions'
    /// <summary>
    /// Change the Workday Account User Name to sUserName for the supplied sEmployerID
    /// </summary>
    /// <param name="sEmployeeID"></param>
    /// <param name="sUserName"></param>
    /// <returns></returns>
    public bool UpdateWorkdayAccountUserName(string sEmployeeID, string sUserName)
    {
      try
      {
        Workday_Account_for_Worker_DataType oWorkerAccountData = new Workday_Account_for_Worker_DataType();
        oWorkerAccountData.User_Name = sUserName;
        return UpdateWorkdayAccount(sEmployeeID, oWorkerAccountData);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
        return false;
      }
    }

    /// <summary>
    /// Update the Workday Account for the supplied sEmployeeID from a supplied oWorkerAccountData object.  NOTE:  The UserName parameter of the oWorkerAccountData object must be set before passing it in.
    /// </summary>
    /// <param name="sEmployeeID"></param>
    /// <param name="oWorkerAccountData"></param>
    /// <returns>bool</returns>
    public bool UpdateWorkdayAccount(string sEmployeeID, Workday_Account_for_Worker_DataType oWorkerAccountData)
    {
      // Human_ResourcesPortClient oHRClient = GetPortClient();
      try
      {
        Worker_ReferenceType oWorker = new Worker_ReferenceType();
        if (CreateWorkerReference(sEmployeeID, ref oWorker))
        {
          Workday_Account_for_Worker_UpdateType oWorkerUpd = new Workday_Account_for_Worker_UpdateType();
          oWorkerUpd.Worker_Reference = oWorker;
          oWorkerUpd.Workday_Account_for_Worker_Data = oWorkerAccountData;

          oHRClient.Update_Workday_Account(oCommonHeader, oWorkerUpd);
          return true;
        }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return false;
    }

    public Get_Workday_Account_ResponseType GetWorkdayAccount(string sEmployeeID, int iPageNumber, int iPageSize, DateSelectionType oDateSelection, DateTime dAsOfEffDate)
    {
      // Human_ResourcesPortClient oHRClient = GetPortClient();
      Get_Workday_Account_ResponseType oWorkdayAccount = null;
      try
      {
        RoleObjectIDType[] oRoleObjID = new RoleObjectIDType[1];
        oRoleObjID[0] = new RoleObjectIDType();
        oRoleObjID[0].type = "Employee_ID";
        oRoleObjID[0].Value = sEmployeeID;

        RoleObjectType[] oRoleObject = new RoleObjectType[1];
        oRoleObject[0] = new RoleObjectType();
        oRoleObject[0].ID = oRoleObjID;

        Get_Workday_Account_RequestType oRequest = new Get_Workday_Account_RequestType();
        Get_Workday_Account_Request_CriteriaType oRequestCriteria = new Get_Workday_Account_Request_CriteriaType();

        Response_FilterType oResponse = new Response_FilterType();
        if (iPageSize > 0)
        {
          oResponse.Count = iPageSize;
          oResponse.CountSpecified = true;
        }
        if (iPageNumber > 0)
        {
          oResponse.Page = iPageNumber;
          oResponse.PageSpecified = true;
        }
        if (oDateSelection == DateSelectionType.DataEntry)
        {
          oResponse.As_Of_Entry_DateTime = dAsOfEffDate;
          oResponse.As_Of_Entry_DateTimeSpecified = true;
        }
        else
        {
          oResponse.As_Of_Effective_Date = dAsOfEffDate;
          oResponse.As_Of_Effective_DateSpecified = true;
        }

        Workday_Account_Response_GroupType oResponseGroup = new Workday_Account_Response_GroupType();
        oResponseGroup.Include_Reference = true;
        oResponseGroup.Include_ReferenceSpecified = true;

        oRequest.Request_Criteria = oRequestCriteria;
        oRequest.Request_References = oRoleObject;
        oRequest.Response_Filter = oResponse;
        oRequest.Response_Group = oResponseGroup;

        oWorkdayAccount = oHRClient.Get_Workday_Account(oCommonHeader, oRequest);

      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oWorkdayAccount;
    }

    #endregion

    #region 'Maintain_Contact_Information functions'

    /// <summary>
    /// Update an employee email address.   
    /// </summary>
    /// <param name="sEmployeeID"></param>
    /// <param name="sEmailAddress"></param>
    /// <param name="eContactType"></param>
    /// <param name="bIsPrimary"></param>
    /// <param name="bCreateNew"></param>
    /// <returns></returns>
    public bool UpdateEmployeeEmail(string sEmployeeID, string sEmailAddress, ContactType eContactType, bool bIsPrimary, bool bIsPublic, bool bCreateNew, bool bIgnorePendingActionValidationError)
    {
      try
      {
        WorkerObjectType[] oWorkerObj = new WorkerObjectType[1];
        Communication_Method_Usage_Information_DataType[] oMethodUsage = new Communication_Method_Usage_Information_DataType[1];
        if (CreateCommunicationMethodUsageObjects(sEmployeeID, ref oWorkerObj, ref oMethodUsage, eContactType, bIsPrimary, bIsPublic))
        {
          Email_Address_Information_DataType[] oEmail = new Email_Address_Information_DataType[1];
          oEmail[0] = new Email_Address_Information_DataType();
          oEmail[0].Email_Address = sEmailAddress;
          oEmail[0].Usage_Data = oMethodUsage;

          Contact_Information_DataType oContactInfo = new Contact_Information_DataType();
          oContactInfo.Email_Address_Data = oEmail;

          Contact_Information_for_Person_Event_DataType oContact = new Contact_Information_for_Person_Event_DataType();
          oContact.Worker_Reference = oWorkerObj[0];
          oContact.Worker_Contact_Information_Data = oContactInfo;
          oContact.Effective_Date = DateTime.Now.ToUniversalTime();
          oContact.Effective_DateSpecified = true;

          Maintain_Contact_Information_for_Person_Event_RequestType oRequest = new Maintain_Contact_Information_for_Person_Event_RequestType();
          oRequest.Maintain_Contact_Information_Data = oContact;
          oRequest.Add_Only = bCreateNew;
          oRequest.Add_OnlySpecified = true;

          oHRClient.Maintain_Contact_Information(oCommonHeader, oRequest);
          return true;
        }
      }
      catch (Exception ex)
      {
        if (CheckPendingActionValidationError(bIgnorePendingActionValidationError, ex)) HandleErr(ex);
      }
      return false;
    }

    /// <summary>
    /// Update an employee phone number.  This makes a number of assumptions to simplify things. 
    /// </summary>
    /// <param name="sEmployeeID"></param>
    /// <param name="sPhoneCountryCode"></param>
    /// <param name="sPhoneNumber"></param>
    /// <param name="sPhoneExtesion"></param>
    /// <param name="eContactType"></param>
    /// <param name="ePhoneDeviceType"></param>
    /// <param name="bIsPrimary"></param>
    /// <param name="bCreateNew"></param>
    /// <returns></returns>
    public bool UpdateEmployeePhone(string sEmployeeID, string sPhoneCountryCode, string sAreaCode, string sPhoneNumber, string sPhoneExtension, ContactType eContactType, PhoneDeviceType ePhoneDeviceType, bool bIsPrimary, bool bIsPublic, bool bCreateNew, bool bIgnorePendingActionValidationError)
    {
      try
      {
        WorkerObjectType[] oWorkerObj = new WorkerObjectType[1];
        Communication_Method_Usage_Information_DataType[] oMethodUsage = new Communication_Method_Usage_Information_DataType[1];
        if (CreateCommunicationMethodUsageObjects(sEmployeeID, ref oWorkerObj, ref oMethodUsage, eContactType, bIsPrimary, bIsPublic))
        {
          Phone_Device_TypeObjectIDType[] oPhoneDeviceID = new Phone_Device_TypeObjectIDType[1];
          oPhoneDeviceID[0] = new Phone_Device_TypeObjectIDType();
          oPhoneDeviceID[0].type = "Phone_Device_Type_ID";
          oPhoneDeviceID[0].Value = ePhoneDeviceType.ToString();

          Phone_Device_TypeObjectType[] oPhoneDevice = new Phone_Device_TypeObjectType[1];
          oPhoneDevice[0] = new Phone_Device_TypeObjectType();
          oPhoneDevice[0].ID = oPhoneDeviceID;

          Phone_Information_DataType[] oPhone = new Phone_Information_DataType[1];
          oPhone[0] = new Phone_Information_DataType();
          oPhone[0].Phone_Device_Type_Reference = oPhoneDevice[0];
          oPhone[0].Usage_Data = oMethodUsage;
          oPhone[0].International_Phone_Code = sPhoneCountryCode;
          oPhone[0].Area_Code = sAreaCode;
          oPhone[0].Phone_Number = sPhoneNumber;
          oPhone[0].Phone_Extension = sPhoneExtension;

          Contact_Information_DataType oContactInfo = new Contact_Information_DataType();
          oContactInfo.Phone_Data = oPhone;

          Contact_Information_for_Person_Event_DataType oContact = new Contact_Information_for_Person_Event_DataType();
          oContact.Worker_Reference = oWorkerObj[0];
          oContact.Worker_Contact_Information_Data = oContactInfo;
          oContact.Effective_Date = DateTime.Now.ToUniversalTime();
          oContact.Effective_DateSpecified = true;

          Maintain_Contact_Information_for_Person_Event_RequestType oRequest = new Maintain_Contact_Information_for_Person_Event_RequestType();
          oRequest.Maintain_Contact_Information_Data = oContact;
          oRequest.Add_Only = bCreateNew;
          oRequest.Add_OnlySpecified = true;

          oHRClient.Maintain_Contact_Information(oCommonHeader, oRequest);
          return true;
        }
      }
      catch (Exception ex)
      {
        if (CheckPendingActionValidationError(bIgnorePendingActionValidationError, ex)) HandleErr(ex);
      }
      return false;
    }
    private bool CheckPendingActionValidationError(bool bIgnorePendingActionValidationError, Exception ex)
    {
      if (bIgnorePendingActionValidationError)
      {
        if (ex.Message != "Validation error occurred. You cannot initiate this action because there are other pending or completed actions for the worker that conflict with this one.") return true;
      }
      return false;
    }

    #endregion

    #region 'Other functions'


    public Get_Job_Profiles_ResponseType GetJobProfiles(Job_Profile_Request_CriteriaType oRequestCriteria, Job_Profile_Request_ReferencesType oRequestReference, Job_Profile_Response_GroupType oResponseGroup, DateTime dAsOfDateTime, DateSelectionType oAsOfDateTimeType, int iPageSize, int iPageNumber)
    {
      Get_Job_Profiles_ResponseType oJobProfiles = null;
      try
      {
        Get_Job_Profiles_RequestType oJobProfilesRequest = new Get_Job_Profiles_RequestType();
        Response_FilterType oResponseFilter = SetResponseFilter(dAsOfDateTime, oAsOfDateTimeType, iPageSize, iPageNumber);

        oJobProfilesRequest.Request_Criteria = oRequestCriteria;
        oJobProfilesRequest.Request_References = oRequestReference;
        oJobProfilesRequest.Response_Filter = oResponseFilter;
        oJobProfilesRequest.Response_Group = oResponseGroup;
        oJobProfiles = oHRClient.Get_Job_Profiles(oCommonHeader, oJobProfilesRequest);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oJobProfiles;
    }

    public List<Job_Profile_Get_DataType> GetAllJobProfiles()
    {
      List<Job_Profile_Get_DataType> oJobProfiles = new List<Job_Profile_Get_DataType>();
      try
      {
        int iPageNumber = 1;
        bool bGotAllData = false;
        while(!bGotAllData && iPageNumber <= MAX_PAGES_TO_REQUEST)
        {
          Get_Job_Profiles_ResponseType oThisJobProfiles = GetJobProfiles(null, null, null, DateTime.Now, DateSelectionType.Effective, MAX_PAGE_SIZE_TO_REQUEST, iPageNumber);
          if(oThisJobProfiles.Response_Data != null)
          {
            foreach (Job_Profile_Get_DataType oJob in oThisJobProfiles.Response_Data)
            {
              if(oJob !=null) oJobProfiles.Add(oJob);
            }
          }
          else
          {
            bGotAllData = true;
          }
          iPageNumber++;
        }
      }catch(Exception ex)
      {
        HandleErr(ex);
      }

      return oJobProfiles;
    }

    public Get_Locations_ResponseType GetLocations(Location_Request_CriteriaType oRequestCriteria, Location_Request_ReferencesType oRequestReference, Location_Response_GroupType oResponseGroup, DateTime dAsOfDateTime, DateSelectionType oAsOfDateTimeType, int iPageSize, int iPageNumber)
    {
      Get_Locations_ResponseType oLocations = null;
      try
      {
        Get_Locations_RequestType oLocationsRequest = new Get_Locations_RequestType();
        Response_FilterType oResponseFilter = SetResponseFilter(dAsOfDateTime, oAsOfDateTimeType, iPageSize, iPageNumber);
        oLocationsRequest.Request_Criteria = oRequestCriteria;
        oLocationsRequest.Request_References = oRequestReference;
        oLocationsRequest.Response_Filter = oResponseFilter;
        oLocationsRequest.Response_Group = oResponseGroup;
        oLocations = oHRClient.Get_Locations(oCommonHeader, oLocationsRequest);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oLocations;
    }

    public List<Location_ResponseType> GetAllLocations()
    {
      List<Location_ResponseType > oLocations = new List<Location_ResponseType>();
      try
      {
        int iPageNumber = 1;
        bool bGotAllData = false;

        Location_Response_GroupType oResponseGroup = new Location_Response_GroupType();
        oResponseGroup.Include_Location_Data = true;
        oResponseGroup.Include_Location_DataSpecified = true;
        oResponseGroup.Include_Reference = true;
        oResponseGroup.Include_ReferenceSpecified = true;

        while (!bGotAllData && iPageNumber <= MAX_PAGES_TO_REQUEST)
        {
          Get_Locations_ResponseType oThisLocations = GetLocations(null, null, oResponseGroup, DateTime.Now, DateSelectionType.Effective, MAX_PAGE_SIZE_TO_REQUEST, iPageNumber);
          if (oThisLocations.Response_Data != null)
          {
            foreach (Location_ResponseType oLocation in oThisLocations.Response_Data)
            {
              if (oLocation != null) oLocations.Add(oLocation);
            }
          }
          else
          {
            bGotAllData = true;
          }
          iPageNumber++;
        }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oLocations;
    }

    #endregion

    #region 'Utilities'
    public bool CreateWorkerReference(string sEmployeeID, ref Worker_ReferenceType oWorker)
    {
      try
      {
        Employee_ReferenceType oEmployee = new Employee_ReferenceType();
        if (CreateEmployeeReference(sEmployeeID, ref oEmployee))
        {
          oWorker = new Worker_ReferenceType();
          oWorker.Item = oEmployee;
          return true;
        }
        else
        {
          return false;
        }
      }
      catch (Exception ex)
      {
        HandleErr(ex);
        return false;
      }
    }

    public bool CreateEmployeeReference(string sEmployeeID, ref Employee_ReferenceType oEmployee)
    {
      try
      {
        IDType oIDType = new IDType();
        oIDType.System_ID = "WD-EMPLID";
        oIDType.Value = sEmployeeID;

        External_Integration_ID_Reference_DataType oID = new External_Integration_ID_Reference_DataType();
        oID.ID = oIDType;

        oEmployee = new Employee_ReferenceType();
        oEmployee.Integration_ID_Reference = oID;
        return true;
      }
      catch (Exception ex)
      {
        HandleErr(ex);
        return false;
      }
    }

    public bool CreateCommunicationMethodUsageObjects(string sEmployeeID, ref WorkerObjectType[] oWorkerObj, ref Communication_Method_Usage_Information_DataType[] oMethodUsage, ContactType eContactType, bool bIsPrimary, bool bIsPublic)
    {
      try
      {
        WorkerObjectIDType[] oWkObjIDType = new WorkerObjectIDType[1];
        oWkObjIDType[0] = new WorkerObjectIDType();
        oWkObjIDType[0].type = "Employee_ID";
        oWkObjIDType[0].Value = sEmployeeID;

        oWorkerObj = new WorkerObjectType[1];
        oWorkerObj[0] = new WorkerObjectType();
        oWorkerObj[0].ID = oWkObjIDType;

        Communication_Usage_TypeObjectIDType[] oUsageTypeID = new Communication_Usage_TypeObjectIDType[1];
        oUsageTypeID[0] = new Communication_Usage_TypeObjectIDType();
        oUsageTypeID[0].type = "Communication_Usage_Type_ID";
        oUsageTypeID[0].Value = eContactType.ToString();
        Communication_Usage_TypeObjectType oUsageType = new Communication_Usage_TypeObjectType();
        oUsageType.ID = oUsageTypeID;

        Communication_Usage_Type_DataType[] oUsageTypeData = new Communication_Usage_Type_DataType[1];
        oUsageTypeData[0] = new Communication_Usage_Type_DataType();
        oUsageTypeData[0].Type_Reference = oUsageType;
        if (bIsPrimary)
        {
          oUsageTypeData[0].Primary = bIsPrimary;
          oUsageTypeData[0].PrimarySpecified = true;
        }

        oMethodUsage = new Communication_Method_Usage_Information_DataType[1];
        oMethodUsage[0] = new Communication_Method_Usage_Information_DataType();
        oMethodUsage[0].Type_Data = oUsageTypeData;
        oMethodUsage[0].Public = bIsPublic;
        oMethodUsage[0].PublicSpecified = true;

        return true;
      }
      catch (Exception ex)
      {
        HandleErr(ex);
        return false;
      }
    }

    public Response_FilterType SetResponseFilter(DateTime dAsOfDateTime, DateSelectionType oAsOfDateTimeType, int iPageSize, int iPageNumber)
    {
      Response_FilterType oResponseFilter = new Response_FilterType();

      if (oAsOfDateTimeType == DateSelectionType.DataEntry) {
        oResponseFilter.As_Of_Entry_DateTime = dAsOfDateTime;
        oResponseFilter.As_Of_Entry_DateTimeSpecified= true;
      }
      else
      {
        oResponseFilter.As_Of_Effective_Date = dAsOfDateTime;
        oResponseFilter.As_Of_Effective_DateSpecified = true;
      }
      if (iPageSize > 0)
      {
        oResponseFilter.Count = iPageSize;
        oResponseFilter.CountSpecified = true;
      }
      if (iPageNumber > 0)
      {
        oResponseFilter.Page = iPageNumber;
        oResponseFilter.PageSpecified = true;
      }
      return oResponseFilter;
    }

    #endregion


  }



}
