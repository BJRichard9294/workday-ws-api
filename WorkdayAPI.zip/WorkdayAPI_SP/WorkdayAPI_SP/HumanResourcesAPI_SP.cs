﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorkdayAPI;
using WorkdayAPI.HumanResources;
using WorkdayIntegrationEntities;
using System.IO;

namespace WorkdayAPI_SP
{
  public class HumanResourcesAPI_SP : WorkdayAPI.HumanResourcesAPI
  {

    private const int MaxRespFilterPageNumber = 50;
    private const int DefaultRespFilterPageSize = 500;
    private const int MaxRespFilterPageSize = 999;


    public HumanResourcesAPI_SP(string sEndpointAddress, string sUsername, string sPassword, HumanResourcesAPI.ErrHandler oInErrHandler) : base(sEndpointAddress, sUsername, sPassword, oInErrHandler)
    {
    }


    #region 'Get_Workers External Application Functions'
    private void Set_Worker_Response_GroupType_ForGetWorkers(ref Worker_Response_GroupType oRespGroup)
    {
      oRespGroup.Include_Employment_Information = true;
      oRespGroup.Include_Employment_InformationSpecified = true;
      oRespGroup.Include_Organizations = true;
      oRespGroup.Include_OrganizationsSpecified = true;
      oRespGroup.Include_Management_Chain_Data = true;
      oRespGroup.Include_Management_Chain_DataSpecified = true;
      oRespGroup.Include_Personal_Information = true;
      oRespGroup.Include_Personal_InformationSpecified = true;
      oRespGroup.Include_Reference = true;
      oRespGroup.Include_ReferenceSpecified = true;
      oRespGroup.Include_User_Account = true;
      oRespGroup.Include_User_AccountSpecified = true;
      oRespGroup.Include_Qualifications = true;
      oRespGroup.Include_QualificationsSpecified = true;
      oRespGroup.Include_Skills = true;
      oRespGroup.Include_SkillsSpecified = true;
    }

    public bool GetWorkersInformation(ref List<WorkdayWorkerInformation> oWDInfoList, bool bIncludeInactive, int iMaxRespFilterPageNumber, int iRespFilterPageSize, DateTime dAsOfDate, DateSelectionType oAsOfDateType)
    {
      return GetWorkersInformation(ref oWDInfoList, bIncludeInactive, iMaxRespFilterPageNumber, iRespFilterPageSize, dAsOfDate, oAsOfDateType, "");
    }
    public bool GetWorkersInformation(ref List<WorkdayWorkerInformation> oWDInfoList, bool bIncludeInactive, int iMaxRespFilterPageNumber, int iRespFilterPageSize, DateTime dAsOfDate, DateSelectionType oAsOfDateType, string sEmployeeID)
    {
      try
      {
        Get_Workers_ResponseType oWorkers = null;
        Worker_Response_GroupType oRespGroup = base.CreateGetWorkersResponseGroupAllItems(false);
        Set_Worker_Response_GroupType_ForGetWorkers(ref oRespGroup);

        Get_Workers_RequestType oRequest = CreateDefaultGetWorkersRequest();

        // If only want active employees
        if (!bIncludeInactive)
        {
          Worker_Request_CriteriaType oReqCriteria = new Worker_Request_CriteriaType();
          oReqCriteria.Exclude_Inactive_Workers = true;
          oReqCriteria.Exclude_Inactive_WorkersSpecified = true;
          oRequest.Request_Criteria = oReqCriteria;
        }

        int iRespFilterPageNumber, iWorkerDataCount;
        bool bAtEndOfWorkers = false;
        oWDInfoList = new List<WorkdayWorkerInformation>();
        DateTime dMin = DateTime.MinValue;

        if (iMaxRespFilterPageNumber == 0 || iMaxRespFilterPageNumber > MaxRespFilterPageNumber) { iMaxRespFilterPageNumber = MaxRespFilterPageNumber; }
        if (iRespFilterPageSize == 0 || iRespFilterPageSize > MaxRespFilterPageSize) { iRespFilterPageSize = DefaultRespFilterPageSize; }

        for (iRespFilterPageNumber = 1; iRespFilterPageNumber <= iMaxRespFilterPageNumber || bAtEndOfWorkers; iRespFilterPageNumber++)
        {
          if (sEmployeeID != ""){
            //                              string sEmployeeID = "801717";
            oWorkers = GetWorker(sEmployeeID, false, null, null, oRespGroup);
          }
          else
          {
            //          oWorkers = GetWorkers(DateSelectionType.DataEntry, dAsOfDataEntryDate, iRespFilterPageSize, iRespFilterPageNumber, oRequest, null, oRespGroup);
            oWorkers = GetWorkers(oAsOfDateType, dAsOfDate, iRespFilterPageSize, iRespFilterPageNumber, oRequest, null, oRespGroup);
          }


          if (oWorkers.Response_Data != null)
          {
            for (iWorkerDataCount = 0; iWorkerDataCount < oWorkers.Response_Data.Length; iWorkerDataCount++)
            {
              if (oWorkers.Response_Data[iWorkerDataCount] != null)
              {
                WorkdayWorkerInformation oWDInfo = new WorkdayWorkerInformation();
                Worker_DataType oWorker = oWorkers.Response_Data[iWorkerDataCount].Worker_Data;

                oWDInfo.EmployeeID = oWorkers.Response_Data[iWorkerDataCount].Worker_Reference.ID[1].Value;

                if (oWorker.Employment_Data != null) oWDInfo.Title = oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Business_Title;
                oWDInfo.FirstName = oWorker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.First_Name;
                oWDInfo.Initial = oWorker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Middle_Name;
                oWDInfo.LastName = oWorker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Last_Name;
                oWDInfo.PreferredFirstName = oWorker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.First_Name;
                if (!string.IsNullOrEmpty(oWorker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.Middle_Name))
                {
                  oWDInfo.PreferredMiddleName = oWorker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.Middle_Name;
                }
                oWDInfo.PreferredLastName = oWorker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.Last_Name;

                bool bGotWork = false, bGotHome = false;

                if (oWorker.Personal_Data.Contact_Data.Email_Address_Data != null)
                {
                  for (int iIndex = 0; ((iIndex < oWorker.Personal_Data.Contact_Data.Email_Address_Data.Length) && !(bGotHome && bGotWork)); iIndex++)
                  {
                    if (oWorker.Personal_Data.Contact_Data.Email_Address_Data[iIndex].Usage_Data[0].Type_Data[0].Primary)
                    {
                      if (oWorker.Personal_Data.Contact_Data.Email_Address_Data[iIndex].Usage_Data[0].Type_Data[0].Type_Reference.ID[1].Value == "WORK")
                      {
                        oWDInfo.WorkEmail = oWorker.Personal_Data.Contact_Data.Email_Address_Data[iIndex].Email_Address;
                        bGotWork = true;
                      }
                      else if (oWorker.Personal_Data.Contact_Data.Email_Address_Data[iIndex].Usage_Data[0].Type_Data[0].Type_Reference.ID[1].Value == "HOME")
                      {
                        oWDInfo.HomeEmail = oWorker.Personal_Data.Contact_Data.Email_Address_Data[iIndex].Email_Address;
                        bGotHome = true;
                      }
                    }
                  }
                }

                bGotWork = false;
                bGotHome = false;
                if (oWorker.Personal_Data.Contact_Data.Phone_Data != null)
                {
                  for (int iIndex = 0; ((iIndex < oWorker.Personal_Data.Contact_Data.Phone_Data.Length) && !(bGotHome && bGotWork)); iIndex++)
                  {
                    if (oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Usage_Data[0].Type_Data[0].Type_Reference.ID[1].Value == "WORK")
                    {
                      if (oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Usage_Data[0].Type_Data[0].Primary)
                      {
                        if (oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Phone_Device_Type_Reference.ID[1].Value == "Landline")
                        {
                          oWDInfo.WorkPhone = oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Phone_Number;
                          oWDInfo.WorkPhoneExtension = oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Phone_Extension;
                          bGotWork = true;
                        }
                        else if (oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Usage_Data[0].Type_Data[0].Type_Reference.ID[1].Value == "HOME")
                        {
                          oWDInfo.HomePhone = oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Area_Code;
                          oWDInfo.HomePhone += ("-" + oWorker.Personal_Data.Contact_Data.Phone_Data[iIndex].Phone_Number).TrimStart('-');
                          bGotHome = true;
                        }
                      }
                    }
                  }
                }


                bGotWork = false;
                bGotHome = false;
                if (oWorker.Personal_Data.Contact_Data.Address_Data != null)
                {
                  for (int iIndex = 0; ((iIndex < oWorker.Personal_Data.Contact_Data.Address_Data.Length) && !(bGotHome && bGotWork)); iIndex++)
                  {
                    if (oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Usage_Data[0].Type_Data[0].Primary)
                    {

                      if (oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Usage_Data[0].Type_Data[0].Type_Reference.ID[1].Value == "WORK")
                      {
                        oWDInfo.WorkAddress1 = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data[0].Value;
                        if (oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data.Length > 1) oWDInfo.WorkAddress2 = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data[1].Value;
                        oWDInfo.WorkCity = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Municipality;
                        oWDInfo.WorkState = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Country_Region_Descriptor;
                        oWDInfo.WorkPostalCode = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Postal_Code;
                        oWDInfo.WorkCountry = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Country_Reference.ID[1].Value;
                        bGotWork = true;
                      }
                      else if (oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Usage_Data[0].Type_Data[0].Type_Reference.ID[1].Value == "HOME")
                      {
                        if (oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data != null)
                        {
                          oWDInfo.HomeAddress1 = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data[0].Value;
                          if (oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data.Length > 1) oWDInfo.HomeAddress2 = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Address_Line_Data[1].Value;
                        }
                        oWDInfo.HomeCity = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Municipality;
                        oWDInfo.HomeState = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Country_Region_Descriptor;
                        oWDInfo.HomePostalCode = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Postal_Code;
                        oWDInfo.HomeCountry = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Country_Reference.ID[1].Value;
                        if (oWDInfo.HomeCountry == "US" && oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Country_Region_Reference != null)
                        {
                          oWDInfo.HomeStateAbbreviated = oWorker.Personal_Data.Contact_Data.Address_Data[iIndex].Country_Region_Reference.ID[1].Value.Replace("USA-", "");
                        }
                        bGotHome = true;
                      }
                    }
                  }
                }


                if (oWorker.User_ID != null) { oWDInfo.UserName = oWorker.User_ID.ToString(); }
                if(oWorker.Organization_Data != null)
                {
                  for (int iIndex = 0; iIndex < oWorker.Organization_Data.Length; iIndex++)
                  {
                    if (oWorker.Organization_Data[iIndex].Organization_Data.Organization_Type_Reference.ID[1].Value.ToLower() == "cost_center")
                    {
                      oWDInfo.Department = oWorker.Organization_Data[iIndex].Organization_Data.Organization_Name;
                      string[] sData = oWDInfo.Department.Split('-');
                      if (sData.Length > 1)
                      {
                        oWDInfo.Department = sData[0].Trim();
                        oWDInfo.CostCenter = sData[1].Trim();
                      }
                      break;
                    }
                  }
                }

                if (oWorker.Management_Chain_Data != null)
                {
                  oWDInfo.ManagerID = oWorker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data[oWorker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data.Length - 1].Manager[0].Worker_Reference.ID[1].Value;
                  oWDInfo.ManagerName = oWorker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data[oWorker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data.Length - 1].Manager[0].Worker_Descriptor;
                }
                oWDInfo.ContingentWorker = "False";

                if (oWorker.Employment_Data != null)
                {
                  if (oWorker.Employment_Data.Worker_Job_Data != null) oWDInfo.Location = oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Business_Site_Summary_Data.Name;
                  oWDInfo.EmployeeType = oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Worker_Type_Reference.ID[1].Value;

                  if (oWorker.Employment_Data.Worker_Status_Data.First_Day_of_WorkSpecified && oWorker.Employment_Data.Worker_Status_Data.First_Day_of_Work > dMin) { oWDInfo.WorkerStartDate = oWorker.Employment_Data.Worker_Status_Data.First_Day_of_Work; }
                  if (oWorker.Employment_Data.Worker_Status_Data.End_Employment_DateSpecified && oWorker.Employment_Data.Worker_Status_Data.End_Employment_Date > dMin) { oWDInfo.EmployeeEndDate = oWorker.Employment_Data.Worker_Status_Data.End_Employment_Date; }
                  if (oWorker.Employment_Data.Worker_Status_Data.TerminatedSpecified && oWorker.Employment_Data.Worker_Status_Data.Termination_Date > dMin) { oWDInfo.TerminationDate = oWorker.Employment_Data.Worker_Status_Data.Termination_Date; }

                  if (oWorkers.Response_Data[iWorkerDataCount].Worker_Reference.ID[1].type == "Contingent_Worker_ID")
                  {
                    oWDInfo.ContingentWorker = "True";
                    if (oWorker.Employment_Data.Worker_Contract_Data.Contract_End_DateSpecified) { oWDInfo.ContractEndDate = oWorker.Employment_Data.Worker_Contract_Data.Contract_End_Date; }
                    if (oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Worker_Type_Reference.ID[1].Value != null) { oWDInfo.EmployeeType = oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Worker_Type_Reference.ID[1].Value.ToString(); }
                  }
                  if (oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Job_Profile_Summary_Data.Job_Profile_Reference != null)
                  {
                    oWDInfo.JobProfileID = oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Job_Profile_Summary_Data.Job_Profile_Reference.ID[1].Value;
                  }
                  if (oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Job_Profile_Summary_Data.Management_Level_Reference != null)
                  {
                    oWDInfo.ManagementLevel = oWorker.Employment_Data.Worker_Job_Data[0].Position_Data.Job_Profile_Summary_Data.Management_Level_Reference.ID[1].Value;
                  }
                  oWDInfo.Active = oWorker.Employment_Data.Worker_Status_Data.Active.ToString();
                }
                oWDInfoList.Add(oWDInfo);
                //                            System.Diagnostics.Debug.WriteLine(oWDInfo.EmployeeID + " : " + oWDInfo.LastName + " : " + oWDInfo.Active);
              }
            }
          }
          // If only want one employee record, get of of loop 
          if (sEmployeeID != "") break;

          }


          return true;
      }
      catch (Exception ex)
      {
        HandleErr(ex);
        return false;
      }

    }
    public bool GetWorkersInformation(ref List<WorkdayWorkerInformation> oWDInfoList, bool bIncludeInactive, DateTime dAsOfDate, DateSelectionType oAsOfDateType)
    {
      return GetWorkersInformation(ref oWDInfoList, bIncludeInactive, MaxRespFilterPageNumber, MaxRespFilterPageSize,  dAsOfDate, oAsOfDateType);
    }


    // BJR 3.28.17 - Suspended work on this as it doesn't seem to be returning transcations for the date range. Not a high priority 
    //  public bool GetWorkersTransactions(ref List<WorkdayWorkerInformation> oWDInfoList, bool bIncludeInactive, int iMaxRespFilterPageNumber, int iRespFilterPageSize, DateTime? oEffectiveDateFrom, DateTime? oEffectiveDateThrough)
    //  {
    //      try
    //      {
    //          Get_Workers_ResponseType oWorkers = null;
    //          Worker_Response_GroupType oRespGroup = CreateGetWorkersResponseGroupAllItems(false);
    //          oRespGroup.Include_Transaction_Log_Data = true;
    //          oRespGroup.Include_Transaction_Log_DataSpecified = true;

    //          Get_Workers_RequestType oRequest = CreateDefaultGetWorkersRequest();

    //          // If only want active employees
    //          if (!bIncludeInactive)
    //          {
    //              Worker_Request_CriteriaType oReqCriteria = new Worker_Request_CriteriaType();
    //              oReqCriteria.Exclude_Inactive_Workers = true;
    //              oReqCriteria.Exclude_Inactive_WorkersSpecified = true;
    //              oRequest.Request_Criteria = oReqCriteria;

    //              if (oEffectiveDateFrom.HasValue && oEffectiveDateThrough.HasValue)
    //              {
    //                  Effective_And_Updated_DateTime_DataType oDateCriteria = new Effective_And_Updated_DateTime_DataType();
    //                  oDateCriteria.Effective_From = Convert.ToDateTime(oEffectiveDateFrom);
    //                  oDateCriteria.Effective_FromSpecified = true;
    //                  oDateCriteria.Effective_Through = Convert.ToDateTime(oEffectiveDateFrom);
    //                  oDateCriteria.Effective_ThroughSpecified = true;
    //                  Transaction_Log_CriteriaType[] oLogCriteria;
    //                  oLogCriteria = new Transaction_Log_CriteriaType[1];
    //                  oLogCriteria[0] = new Transaction_Log_CriteriaType();
    //                  oLogCriteria[0].Transaction_Date_Range_Data = oDateCriteria;
    //                  oReqCriteria.Transaction_Log_Criteria_Data = oLogCriteria;
    //              }
    //          }

    //          int iRespFilterPageNumber, iWorkerDataCount;
    //          bool bAtEndOfWorkers = false;
    //          oWDInfoList = new List<WorkdayWorkerInformation>();
    //          DateTime dDateSelection = DateTime.Now, dMin = DateTime.MinValue;

    //          if (iMaxRespFilterPageNumber == 0 || iMaxRespFilterPageNumber > MaxRespFilterPageNumber) { iMaxRespFilterPageNumber = MaxRespFilterPageNumber; }
    //          if (iRespFilterPageSize == 0 || iRespFilterPageSize > MaxRespFilterPageSize) { iRespFilterPageSize = DefaultRespFilterPageSize; }

    //          for (iRespFilterPageNumber = 1; iRespFilterPageNumber <= iMaxRespFilterPageNumber || bAtEndOfWorkers; iRespFilterPageNumber++)
    //          {
    ////              string sEmployeeID = "802852";
    //  //            oWorkers = GetWorker(sEmployeeID, false, null, null, oRespGroup);
    //                                 oWorkers = GetWorkers(DateSelectionType.DataEntry, dDateSelection, iRespFilterPageSize, iRespFilterPageNumber,  oRequest, null, oRespGroup);

    //              if (oWorkers.Response_Data != null)
    //              {
    //                  for (iWorkerDataCount = 0; iWorkerDataCount < oWorkers.Response_Data.Length; iWorkerDataCount++)
    //                  {
    //                      if (oWorkers.Response_Data[iWorkerDataCount] != null)
    //                      {
    //                          WorkdayWorkerInformation oWDInfo = new WorkdayWorkerInformation();
    //                          Worker_DataType oWorker = oWorkers.Response_Data[iWorkerDataCount].Worker_Data;

    //                          if(oWorker.Transaction_Log_Entry_Data!= null)
    //                          {
    //                              string s = "stop";
    //                          }


    //                      }
    //                  }
    //              }
    //          }


    //          return true;
    //      }
    //      catch (Exception ex)
    //      {
    //          HandleErr(ex);
    //          return false;
    //      }

    //  }



    public bool GetSaveWorkersDocuments(string sSavePath)
    {
      if (!Directory.Exists(sSavePath)) { throw new Exception("The directory " + sSavePath + " does not exist."); }

      try
      {
        Get_Workers_ResponseType oWorkers = null;
        Worker_Document_WWSType[] oWorkerDocuments;
        Worker_Response_GroupType oRespGroup = CreateGetWorkersResponseGroupAllItems(false);

        oRespGroup.Include_Worker_Documents = true;
        oRespGroup.Include_Worker_DocumentsSpecified = true;

        int iRespFilterPageNumber, iMaxRespFilterPageNumber = MaxRespFilterPageNumber, iRespFilterPageSize = DefaultRespFilterPageSize, iWorkerDataCount, iWorkerDocCount;
        string sWorkerDirectory, sDocumentFile;
        bool bAtEndOfWorkers = false;
        DateTime dDateSelection = DateTime.Now;

        for (iRespFilterPageNumber = 1; iRespFilterPageNumber <= iMaxRespFilterPageNumber || bAtEndOfWorkers; iRespFilterPageNumber++)
        {
          oWorkers = GetWorkers(DateSelectionType.DataEntry, dDateSelection, iRespFilterPageSize, iRespFilterPageNumber);

          for (iWorkerDataCount = 0; iWorkerDataCount < iMaxRespFilterPageNumber; iWorkerDataCount++)
          {
            if (oWorkers.Response_Data[iWorkerDataCount] == null)
            {
              bAtEndOfWorkers = true;
            }
            else
            {
              oWorkerDocuments = oWorkers.Response_Data[iWorkerDataCount].Worker_Data.Worker_Document_Data;
              if (oWorkerDocuments != null)
              {
                sWorkerDirectory = sSavePath + oWorkers.Response_Data[iWorkerDataCount].Worker_Data.Worker_ID + "\\";
                if (!Directory.Exists(sWorkerDirectory)) { Directory.CreateDirectory(sWorkerDirectory); }

                for (iWorkerDocCount = 0; iWorkerDocCount < oWorkerDocuments.Length; iWorkerDocCount++)
                {
                  sDocumentFile = sWorkerDirectory + oWorkerDocuments[iWorkerDocCount].Worker_Document_Detail_Data.Filename;
                  File.WriteAllBytes(sDocumentFile, oWorkerDocuments[iWorkerDocCount].Worker_Document_Detail_Data.File);
                }
              }
            }
          }
        }
        return true;
      }
      catch (Exception ex)
      {
        HandleErr(ex);
        return false;
      }
    }

    #endregion

    #region 'Other Human Resources Functions'



    #endregion

  }
}
