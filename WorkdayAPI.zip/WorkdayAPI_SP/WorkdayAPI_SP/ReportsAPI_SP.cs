﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorkdayAPI;


namespace WorkdayAPI_SP
{
  public class ReportsAPI_SP : WorkdayAPI.ReportsAPI
  {

    public ReportsAPI_SP(string sUsername, string sPassword, ReportsAPI.ErrHandler oInErrHandler) : base(sUsername, sPassword, oInErrHandler)
    {
    }

  }
}
