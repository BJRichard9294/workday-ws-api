﻿namespace WorkdayAPI_SPTester
{
    partial class frmWorkdayAPISPTester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDoTest = new System.Windows.Forms.Button();
            this.btnGetWorkerDocs = new System.Windows.Forms.Button();
            this.txtResults = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnDoTest
            // 
            this.btnDoTest.Location = new System.Drawing.Point(12, 12);
            this.btnDoTest.Name = "btnDoTest";
            this.btnDoTest.Size = new System.Drawing.Size(75, 23);
            this.btnDoTest.TabIndex = 0;
            this.btnDoTest.Text = "Do Test";
            this.btnDoTest.UseVisualStyleBackColor = true;
            this.btnDoTest.Click += new System.EventHandler(this.btnDoTest_Click);
            // 
            // btnGetWorkerDocs
            // 
            this.btnGetWorkerDocs.Location = new System.Drawing.Point(12, 59);
            this.btnGetWorkerDocs.Name = "btnGetWorkerDocs";
            this.btnGetWorkerDocs.Size = new System.Drawing.Size(107, 23);
            this.btnGetWorkerDocs.TabIndex = 1;
            this.btnGetWorkerDocs.Text = "Get Worker Docs";
            this.btnGetWorkerDocs.UseVisualStyleBackColor = true;
            this.btnGetWorkerDocs.Click += new System.EventHandler(this.btnGetWorkerDocs_Click);
            // 
            // txtResults
            // 
            this.txtResults.Location = new System.Drawing.Point(12, 177);
            this.txtResults.Multiline = true;
            this.txtResults.Name = "txtResults";
            this.txtResults.Size = new System.Drawing.Size(555, 162);
            this.txtResults.TabIndex = 2;
            // 
            // frmWorkdayAPISPTester
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 351);
            this.Controls.Add(this.txtResults);
            this.Controls.Add(this.btnGetWorkerDocs);
            this.Controls.Add(this.btnDoTest);
            this.Name = "frmWorkdayAPISPTester";
            this.Text = "Workday API - SP Test Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDoIt;
        private System.Windows.Forms.Button btnDoTest;
        private System.Windows.Forms.Button btnGetWorkerDocs;
        private System.Windows.Forms.TextBox txtResults;
    }
}

