﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using WorkdayAPI;
using System.ServiceModel;


namespace WorkdayAPI
{
    public class ReportsAPI
    {
    private string psUsername, psPassword;

    public delegate void ErrHandler(Exception ex);
    public ErrHandler oErrHandler = null;

    public ReportsAPI( string sUsername, string sPassword, ErrHandler oInErrHandler)
    {
      psUsername = sUsername;
      psPassword = sPassword;
      oErrHandler = oInErrHandler;
    }


    public Report_LocationDirectory.Report_EntryType[] RunLocationDirectory(string sVersion, string sEndpointAddress)
    {
      Report_LocationDirectory.Report_EntryType[] oRep_LocationDirectory=null;
      try
      {
        EndpointAddress oEndpoint = new EndpointAddress(sEndpointAddress);
        Report_LocationDirectory.ReportPortClient oClient = new Report_LocationDirectory.ReportPortClient(ServiceUtils.GetCustomBinding(), oEndpoint);
        oClient.ClientCredentials.UserName.UserName = psUsername;
        oClient.ClientCredentials.UserName.Password = psPassword;

        Report_LocationDirectory.Execute_ReportOutput oOut = new Report_LocationDirectory.Execute_ReportOutput();
        Report_LocationDirectory.Execute_ReportType oRun = new Report_LocationDirectory.Execute_ReportType();
        oRep_LocationDirectory = oClient.Execute_Report(oRun);
      }
      catch (Exception ex)
      {
        HandleErr(ex);
      }
      return oRep_LocationDirectory;
    }
    public void HandleErr(Exception ex)
    {
      oErrHandler.Invoke(ex);
    }
  }


}
